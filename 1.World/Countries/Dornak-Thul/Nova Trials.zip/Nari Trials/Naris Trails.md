Vision 1: 
Du stehst an einem klaren Fluss, das Wasser glitzert im Licht. Plötzlich hörst du ein leises Wimmern. Am Ufer findest du ein verletztes Tier – ein Hirsch mit Pfeil in der Flanke. Ein Jäger naht, bereit das Tier zu töten, um seine Kinder zu ernähren.

Vision 2 

Schwur zu altem Freund oder das Richtige tun

Vision 3
Eigene Macht steigern oder das richtige tun (Politisch).

Vision 4
Das eigene leben oder das von adneren Schützen

Vision 5 
Verantwortung für eigenen Fehler übernehmen oder nicht